
public class Main {

	public static void main(String[] args) {
		Home home = new Home();


		//Quiz quiz = new Quiz();
	}

}
